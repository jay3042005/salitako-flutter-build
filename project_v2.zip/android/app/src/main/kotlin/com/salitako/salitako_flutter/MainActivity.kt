package com.salitako.salitako_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
